var indexSectionsWithContent =
{
  0: "abcdefgimnprstuvw",
  1: "s",
  2: "s",
  3: "abcdefgimnprstuvw",
  4: "s",
  5: "s",
  6: "s",
  7: "s",
  8: "st",
  9: "aegimpsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};

