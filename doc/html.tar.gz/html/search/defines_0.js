var searchData=
[
  ['scorep_5fmetric_5fplugin_5fentry',['SCOREP_METRIC_PLUGIN_ENTRY',['../SCOREP__MetricPlugins_8h.html#a6107d9468ac980a94ad707bd40a40e40',1,'SCOREP_MetricPlugins.h']]],
  ['scorep_5fmetric_5fplugin_5fversion',['SCOREP_METRIC_PLUGIN_VERSION',['../SCOREP__MetricPlugins_8h.html#a19947f3f006b54f239f9131e32191392',1,'SCOREP_MetricPlugins.h']]],
  ['scorep_5fsubstrate_5fplugin_5fentry',['SCOREP_SUBSTRATE_PLUGIN_ENTRY',['../SCOREP__SubstratePlugins_8h.html#ac9e26aec6387984b9bb3b2490f1356ec',1,'SCOREP_SubstratePlugins.h']]],
  ['scorep_5fsubstrate_5fplugin_5fundefined_5fmanagement_5ffunctions',['SCOREP_SUBSTRATE_PLUGIN_UNDEFINED_MANAGEMENT_FUNCTIONS',['../SCOREP__SubstratePlugins_8h.html#a10b3bb0f58bfa8bb95822c4b3357e476',1,'SCOREP_SubstratePlugins.h']]],
  ['scorep_5fsubstrate_5fplugin_5fversion',['SCOREP_SUBSTRATE_PLUGIN_VERSION',['../SCOREP__SubstratePlugins_8h.html#a7d1bbc495c8dfe980c64e2e10d97cba6',1,'SCOREP_SubstratePlugins.h']]],
  ['scorep_5fuser_5finvalid_5fparameter',['SCOREP_USER_INVALID_PARAMETER',['../SCOREP__User__Types_8h.html#a8255dceb835519d1a95b5812d99be9c2',1,'SCOREP_User_Types.h']]],
  ['scorep_5fuser_5finvalid_5fregion',['SCOREP_USER_INVALID_REGION',['../SCOREP__User__Types_8h.html#a46062b8aeffded08e6eb63d9d70d734b',1,'SCOREP_User_Types.h']]]
];
