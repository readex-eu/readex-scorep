var searchData=
[
  ['mode',['mode',['../structSCOREP__Metric__Plugin__MetricProperties.html#a5a9e17152a991a44a3e074119bb7f07c',1,'SCOREP_Metric_Plugin_MetricProperties::mode()'],['../structSCOREP__Metric__Properties.html#a84d31ac6a1ece2881b223584b8fc0b4c',1,'SCOREP_Metric_Properties::mode()']]]
];
