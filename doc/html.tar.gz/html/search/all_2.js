var searchData=
[
  ['core_5ftask_5fcomplete',['core_task_complete',['../structSCOREP__SubstratePluginInfo.html#a7d100aecc610c9787a3c58c34dc974d3',1,'SCOREP_SubstratePluginInfo']]],
  ['core_5ftask_5fcreate',['core_task_create',['../structSCOREP__SubstratePluginInfo.html#a45ffc744fcc26bbddf9f71c8032f075e',1,'SCOREP_SubstratePluginInfo']]],
  ['create_5flocation',['create_location',['../structSCOREP__SubstratePluginInfo.html#a39d6534096a6ca9d9a0b846be6f9eca4',1,'SCOREP_SubstratePluginInfo']]]
];
