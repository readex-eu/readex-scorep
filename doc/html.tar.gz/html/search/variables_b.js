var searchData=
[
  ['reserved',['reserved',['../structSCOREP__Metric__Plugin__Info.html#af0cfb67a7b18826065a11700dd0d230d',1,'SCOREP_Metric_Plugin_Info']]],
  ['run_5fper',['run_per',['../structSCOREP__Metric__Plugin__Info.html#ad0f4d332ca0a1122dfa7ab3d6e1b94c9',1,'SCOREP_Metric_Plugin_Info']]]
];
