var searchData=
[
  ['activate_5fcpu_5flocation',['activate_cpu_location',['../structSCOREP__SubstratePluginInfo.html#ab0dfb2a5e35c4dfb131b28c5e412d531',1,'SCOREP_SubstratePluginInfo']]],
  ['add_5fcounter',['add_counter',['../structSCOREP__Metric__Plugin__Info.html#a772e897a7e8113b5c82792d8899f1d4c',1,'SCOREP_Metric_Plugin_Info']]],
  ['assign_5fid',['assign_id',['../structSCOREP__SubstratePluginInfo.html#afafe19469d8bd367ecbd90abe6dc9394',1,'SCOREP_SubstratePluginInfo']]]
];
